<?php

use Illuminate\Support\Facades\Route;
use Modules\TA\Http\Controllers\API\TAProfileController;


// Route::prefix('v1')->group(function () {
//     Route::apiResource('ta_profile', TAProfileController::class);
// });
