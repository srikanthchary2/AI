<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SarasAI\\Providers\\SarasAIServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SarasAI\\Providers\\SarasAIServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);