<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\TA\\Providers\\TAServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\TA\\Providers\\TAServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);