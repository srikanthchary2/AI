<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AuthService\\Providers\\AuthServiceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AuthService\\Providers\\AuthServiceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);