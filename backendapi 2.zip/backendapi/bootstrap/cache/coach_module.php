<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Coach\\Providers\\CoachServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Coach\\Providers\\CoachServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);